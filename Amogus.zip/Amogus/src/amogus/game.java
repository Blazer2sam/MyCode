/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package amogus;

import java.awt.*;
import javax.swing.*;
import java.util.Random;
/**
 *
 * @author Spedley
 */
public class game {
    
    public game(){
        
        //random number that is used to generate the imposter
        int min = 1;
        int max = 3;
        Random random = new Random();
	int value = random.nextInt(max + min) + min;		
        
        JFrame frame = new JFrame();
        JPanel root = new JPanel();
        
        //Icons used for buttons
        Icon amongus1 = new ImageIcon("C:\\Users\\Spedley\\Desktop\\Code\\Amogus\\among1.png");
        Icon amongus2 = new ImageIcon("C:\\Users\\Spedley\\Desktop\\Code\\Amogus\\among2.png");
        Icon amongus3 = new ImageIcon("C:\\Users\\Spedley\\Desktop\\Code\\Amogus\\among3.png");
        Icon dead = new ImageIcon("C:\\Users\\Spedley\\Desktop\\Code\\Amogus\\dead.png");
        
        //character 1
        JButton b1 = new JButton();
        b1.setIcon(amongus1);
        b1.setBounds(80, 20, 20, 40);
        
        //character 2
        JButton b2 = new JButton();
        b2.setBounds(120, 20, 20, 40);
        b2.setIcon(amongus2);
        
        //character 3
        JButton b3 = new JButton();
        b3.setBounds(160, 20, 20, 40);
        b3.setIcon(amongus3);
        
        //result label
        JLabel result = new JLabel();
        result.setBounds(10, 100, 50, 20);
        
        //when the character the following will determine if you guessed the right character
        b1.addActionListener(e ->{
            if(value == 1){
                result.setText("You win");
                b2.setEnabled(false);
                b3.setEnabled(false);
            }
            else{
                result.setText("You lost");
                b1.setIcon(dead);
                b2.setEnabled(false);
                b3.setEnabled(false);
            }
        });
        
        b2.addActionListener(e ->{
            if(value == 2){
                result.setText("You win");
                b1.setEnabled(false);
                b3.setEnabled(false);
            }
            else{
                result.setText("You lost");
                b2.setIcon(dead);
                b1.setEnabled(false);
                b3.setEnabled(false);
            }
        });
        
        b3.addActionListener(e ->{
            if(value == 3){
                result.setText("You win");
                b2.setEnabled(false);
                b1.setEnabled(false);
            }
            else{
                result.setText("You lost");
                b3.setIcon(dead);
                b2.setEnabled(false);
                b1.setEnabled(false);
            }
        });
        
        //adds components to panel
        root.add(b1);
        root.add(b2);
        root.add(b3);
        root.add(result);
        
        root.setLayout(null);
        
        frame.getContentPane().add(root);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300,200);
        frame.setLocation(500, 300);
        frame.setVisible(true);
                
    }
}
