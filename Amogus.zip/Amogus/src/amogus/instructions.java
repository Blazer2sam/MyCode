


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package amogus;

import javax.swing.*;

/**
 *
 * @author Spedley
 */
public class instructions {
    
    instructions(){
        JFrame frame = new JFrame();
        JPanel root = new JPanel();
        
        JLabel rules1 = new JLabel("Amogus");
        rules1.setBounds(200, 5, 200, 15);
        
        JLabel rules2 = new JLabel("There are 3 members on a ship.");
        rules2.setBounds(10, 20, 200, 15);
        
        JLabel rules3 = new JLabel("One of them is an imposter.");
        rules3.setBounds(10, 40, 200, 15);
        
        JLabel rules4 = new JLabel("It is your job to guess which member is the imposter.");
        rules4.setBounds(10, 60, 300, 15);
        
        JLabel rules5 = new JLabel("Guess which one is the imposter.");
        rules5.setBounds(10, 80, 300, 15);
        
        JLabel rules6 = new JLabel("If you guess correct you win. Otherwise you lose.");
        rules6.setBounds(10, 100, 300, 15);
        
        //creating button
        JButton okay = new JButton("Okay");
        okay.setBounds(200, 300, 100, 60);
        
        //creates the game object after okay button is clicked
        okay.addActionListener(e ->{
            new game();
            frame.dispose();
        });
        
        //adding components to root
        root.add(okay);
        root.add(rules1);
        root.add(rules2);
        root.add(rules3);
        root.add(rules4);
        root.add(rules5);
        root.add(rules6);
        
        root.setLayout(null);
        
        //setting up frame
        frame.getContentPane().add(root);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,400);
        frame.setLocation(500, 300);
        frame.setVisible(true);
    }
}
